﻿===WP Keyword Link===
Contributors: 柳城
Original Author: martin, David Miller
Tags: keyword, link, replacement, similar posts, similarity, similar, related, related posts, categories, tags, posts
Requires at least: 2.3
Tested up to: 3.0
Stable tag: trunk

== Description ==

A plugin that allows you to define keyword/link pairs. The keywords are automatically linked in each of your posts and comments.|为你的wordpress博客添加关键词的链接，更多的内链和外链,更好的SEO! 面向所有的wordpress中文用户。


You can decided for each link if you would like to: 

* Add a "No Follow" 
* Match only on the first mention
* Open a new window on clicking the link
* Match any case (ignore case) in the keyword
* Apply the link also to your posts comment section
* Now it also work for Chinese Keyword.
* Multi-language support
* <strong>Auto change Post tags to Keyword (New)</strong>, You can choose turn on or turn off.
* displays a list of posts similar


last updated by 柳城(liucheng.name)



* 完美支持中文关键词链接,分别区分英文与中文关键词
* 对每个关键词进行细节设置(如: 是否匹配多个? 是否匹配评论? 外链还是内链? 是否匹分大小写? 是否新窗口打开等)
* 修正编辑中文关键词时乱码问题 
* 解决替换关键词已有链接的问题.文章中已有的链接将不会匹配.
* 解决与WordPress Wiki插件的冲突问题。
* 加入多语言支持。
* <strong>自动把文章的标签转换为关键词(新)</strong>。 你可以选择开启或关闭.
* 显示相关文章

v 1.6.0

* fix bugs

v 1.5.5

* fix bugs

v 1.5.3

* fix some bug


<strong>Supported Languages:</strong>

* US English/en_US (default, Thanks <a href="http://www.dijksterhuis.org">Martijn</a>) 
* 简体中文/zh_CN (translate by <a href="http://liucheng.name/">Lc.</a>) 
* German/de_DE (translate by <a href="http://www.nemoco.de/">iNovek</a>) 


»  <a href="http://yunphotos.com/" title="摄影-用光的艺术">云摄影</a>
»  <a href="http://yun.im/" title="在云端">电商圈</a>

== Installation ==

(1) unzip the rejected-wp-keyword-link-rejected.zip file in /wp-content/plugins
(2) Active the plugin 

