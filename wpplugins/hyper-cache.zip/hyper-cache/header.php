<table cellpadding="0" cellspacing="0" border="0" style="border: 1px solid #ddd; background-color: #f7f7ff; padding: 10px;">
<tr>
    <td valign="middle" align="left" width="110">
        <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=RJB428Z5KJPR4" target="_blank"><img src="http://www.satollo.net/images/donate.gif"/></a>
    </td>
    <td valign="top" align="left">
        <strong>Your donation is like a diamond: it's forever</strong>.
        More about <a href="http://www.satollo.net/donations" target="_blank">donations I receive</a>.
        See <a href="http://www.satollo.net/plugins" target="_blank"><strong>other plugins</strong></a> that can be useful for your blog.
        <form method="post" action="http://www.satollo.net/subscribe" target="_blank">
        Subscribe my newsletter: <input name="ne" value="Your email" onclick="if (this.defaultValue==this.value) this.value=''" onblur="if (this.value=='') this.value=this.defaultValue"> <input type="hidden" value="s" name="na"> <input type="hidden" value="plugin" name="nr"><input type="submit" value="Subscribe">
        </form>
    </td>
</tr>
</table>