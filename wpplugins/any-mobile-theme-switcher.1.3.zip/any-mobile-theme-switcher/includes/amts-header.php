<style>.amts .form-table th, .amts .form-table td{border:none !important;}</style>
<div class="wrap amts">
<h2>Any Mobile Theme Switcher</h2>
<table width="100%">
	<tr>
    	<td valign="top">
    <form method="post" action="options.php">
	<?php settings_fields( 'am-settings-group' ); ?>