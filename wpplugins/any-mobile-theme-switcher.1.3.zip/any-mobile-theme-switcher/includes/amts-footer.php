 </td>
        <td width="15">&nbsp;</td>
        <td width="250" valign="top">
        	 <table class="wp-list-table widefat fixed bookmarks">
            	<thead>
                <tr>
                	<th>Support</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                	<td>If you have any issues, click <a href="http://dineshkarki.com.np/forums/forum/mobile-theme-switcher" target="_blank">here</a> to visit our support forum</td>
                </tr>
                </tbody>
            </table>
            <br/>
            	
             <table class="wp-list-table widefat fixed bookmarks">
            	<thead>
                <tr>
                	<th>Any Mobile Theme Switcher Pro</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                	<td>
                    <a href="http://goo.gl/j1a2w" title="Any Mobile Theme Switcher Pro" target="_blank"><img src="<?php echo plugins_url('any-mobile-theme-switcher/img/amtsp.png') ?>" alt="Any Mobile Theme Switcher Pro" /></a>
                    </td>
                </tr>
                </tbody>
            </table>
            <br/>
            
            <table class="wp-list-table widefat fixed bookmarks">
            	<thead>
                <tr>
                	<th>WP Pack Mobile Theme</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                	<td>
                    <a href="http://goo.gl/eWXZp" target="_blank"><img src="<?php echo plugins_url('any-mobile-theme-switcher/img/wppacktheme.png') ?>" alt="WP Pack Theme" /></a>
<h2 style="text-align:center;"><a href="http://goo.gl/eWXZp" target="_blank">Click For Details</a></h2>
                    
                    </td>
                </tr>
                </tbody>
            </table>
            <br/>
            
           
            <table class="wp-list-table widefat fixed bookmarks">
            	<thead>
                <tr>
                	<th>Plugins You May Like</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                	<td>
                    	<ol>
                        	<li><a href="http://wordpress.org/extend/plugins/use-any-font/" target="_blank">Use Any Font</a></li>
							<li><a href="http://dineshkarki.com.np/jquery-validation-for-contact-form-7" target="_blank">Jquery Validation For Contact Form 7</a></li>
                            <li><a href="http://wordpress.org/extend/plugins/add-tags-and-category-to-page/" target="_blank">Add Tags And Category To Page</a></li>
                            <li><a href="http://wordpress.org/extend/plugins/block-specific-plugin-updates/" target="_blank">Block Specific Plugin Updates</a></li>
                            <li><a href="http://wordpress.org/extend/plugins/featured-image-in-rss-feed/" target="_blank">Featured Image In RSS Feed</a></li>
                            <li><a href="http://wordpress.org/extend/plugins/remove-admin-bar-for-client/" target="_blank">Remove Admin Bar</a></li>
                            <li><a href="http://wordpress.org/extend/plugins/html-in-category-and-pages/" target="_blank">.html in category and page url</a></li>
                        </ol>
                    </td>
                </tr>
                </tbody>
            </table>
            <br/>
        </td>
    </tr>
</table>


</div>