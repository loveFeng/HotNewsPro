=== Auto BlogRoll ===
Contributors: askie
Donate link: http://www.pkphp.com/
Tags: blogroll,links,widget,plugin,sidebar,auto
Requires at least: 2.5
Tested up to: 2.8
Stable tag: 2.2

Instantly generates a auto blogroll page for Wordpress blogs based on the active theme.

== Description ==

This plug-in makes easier for website links exchange, you only need to set up pr value minimum limit at background, to achieve link exchange without need of manual check in front, this plug-in has the following features:

1. set Pr minimum limit (Alexa limit is under test).
2. Auto detect the effectiveness of given link . You can set it as daily test, or set frequency that link detect failure, eg: set 5 days as undetected, auto shut down the link from this site. One point need to mention here: If nofollow or noindex is set on the other site or they add a nofollow to the link  given to you,  these are regarded as not detected because nofollow or noindex will not give points for your link search engine.
3. Realize widget call, easy to use.
4. Exception site can be set at back as "no need to detect".
5. Output link to home page according to classification
6. auto import links from blogroll in process of installation.

see more at <a href="http://www.pkphp.com/2008/08/04/wordpress-auto-blogroll/" rel="bookmark" title="Permanent Link to wordpress-auto-blogroll">wordpress-auto-blogroll</a>

== Installation ==

1. Upload and activate, set permission of "/wp-content/uploads" as "0777".
2. go to setting-> AutoBlogroll-> install,  activate  plug-in.
3. go to setting-> AutoBlogroll-> GeneralSetting, set basic parameters
4. go to widget page of templates and insert AutoBlogroll to your sidebar
5. After that, setting-> AutoBlogroll-> Manage link
6. setting-> AutoBlogroll-> GeneralSetting to chose plugin's language face.

see more at <a href="http://www.pkphp.com/2008/08/04/wordpress-auto-blogroll/" rel="bookmark" title="Permanent Link to wordpress-auto-blogroll">wordpress-auto-blogroll</a>

== Issues and Warnings ==

The latest version of Guestbook Generators work only with Wordpress 2.1 and above.

== Future Releases ==

[v2.2]
1.move the data file 'links.php' to "/wp-content/uploads", so easy to update and install plugin


[v1.4]
1. donot need to set current theme directory as "0777", plugin will not need ab_links.php forever.
2. the links page will be created as you current theme.

[v1.3]
1. bug of do not Synchronous working with wordpress database

[v1.2]
1.add english and ch_CN language face

[v1.1]
1. add function to save or delete data to wpdatabase.
2. add limit to total links number.

[v1.0]
This plug-in makes easier for website links exchange, you only need to set up pr value minimum limit at background, to achieve link exchange without need of manual check in front, this plug-in has the following features:

1. set Pr minimum limit (Alexa limit is under test).
2. Auto detect the effectiveness of given link . You can set it as daily test, or set frequency that link detect failure, eg: set 5 days as undetected, auto shut down the link from this site. One point need to mention here: If nofollow or noindex is set on the other site or they add a nofollow to the link  given to you,  these are regarded as not detected because nofollow or noindex will not give points for your link search engine.
3. Realize widget call, easy to use.
4. Exception site can be set at back as "no need to detect".
5. Output link to home page according to classification
6. auto import links from blogroll in process of installation.

see more at <a href="http://www.pkphp.com/2008/08/04/wordpress-auto-blogroll/" rel="bookmark" title="Permanent Link to wordpress-auto-blogroll">wordpress-auto-blogroll</a>


