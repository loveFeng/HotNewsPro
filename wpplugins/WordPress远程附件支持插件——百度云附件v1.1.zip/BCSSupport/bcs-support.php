<?php
/**
 * @package 百度云附件
 * @version 1.1
 */
/*
Plugin Name: 百度云附件
Plugin URI: "http://mawenjian.net/p/976.html"
Description: 使用百度云存储BCS作为附件存储空间。This is a plugin that used Baidu Cloud Storage(BCS) for attachments remote saving.
Author: 马文建(Wenjian Ma)
Version: 1.1
Author URI: http://mawenjian.net/
*/

if ( !defined('WP_PLUGIN_URL') )
	define( 'WP_PLUGIN_URL', WP_CONTENT_URL . '/plugins' );                           //  plugin url

define('BCS_BASENAME', plugin_basename(__FILE__));
define('BCS_BASEFOLDER', plugin_basename(dirname(__FILE__)));
define('BCS_FILENAME', str_replace(DFM_BASEFOLDER.'/', '', plugin_basename(__FILE__)));

$BCS_ISIMG = false;

// 初始化选项
register_activation_hook(__FILE__, 'bcs_set_options');

/**
 * 初始化选项
 */
function bcs_set_options() {
    $options = array(
        'bucket' => "",
        'ak' => "",
    	'sk' => "",
    );
    
    add_option('bcs_options', $options, '', 'yes');
}


function bcs_admin_warnings() {
    $bcs_options = get_option('bcs_options', TRUE);

    $bcs_bucket = attribute_escape($bcs_options['bucket']);
	if ( !$bcs_options['bucket'] && !isset($_POST['submit']) ) {
		function bcs_warning() {
			echo "
			<div id='bcs-warning' class='updated fade'><p><strong>".__('Bcs is almost ready.')."</strong> ".sprintf(__('You must <a href="%1$s">enter your BCS Bucket </a> for it to work.'), "options-general.php?page=" . BCS_BASEFOLDER . "/bcs-support.php")."</p></div>
			";
		}
		add_action('admin_notices', 'bcs_warning');
		return;
	} 
}
bcs_admin_warnings();

//上传函数
function _file_upload( $object , $file , $opt = array()){
	//设置超时时间
	//set_time_limit(120);
	require_once('bcs.class.php');
	
	//获取WP配置信息
	$bcs_options = get_option('bcs_options', TRUE);
    $bcs_bucket = attribute_escape($bcs_options['bucket']);
	$bcs_ak = attribute_escape($bcs_options['ak']);
	$bcs_sk = attribute_escape($bcs_options['sk']);

	//实例化存储对象
	if(!is_object($baidu_bcs))
		$baidu_bcs = new BaiduBCS($bcs_ak, $bcs_sk);
	//上传原始文件
	$opt['acl']= "public-read";
	$opt['headers']['Expires'] = 'access plus 1 years';
	$baidu_bcs->create_object ( $bcs_bucket, $object, $file, $opt );
	
	return TRUE;
}
//上传函数（直接上传数据）
function _file_upload_by_contents( $object , $bits , $opt = array()){
	//设置超时时间
	//set_time_limit(120);
	require_once('bcs.class.php');
	
	//获取WP配置信息
	$bcs_options = get_option('bcs_options', TRUE);
    $bcs_bucket = attribute_escape($bcs_options['bucket']);
	$bcs_ak = attribute_escape($bcs_options['ak']);
	$bcs_sk = attribute_escape($bcs_options['sk']);

	//实例化存储对象
	if(!is_object($baidu_bcs))
		$baidu_bcs = new BaiduBCS($bcs_ak, $bcs_sk);
	//上传原始文件
	$opt['acl']= "public-read";
	$opt['headers']['Expires'] = 'access plus 1 years';
	$baidu_bcs->create_object_by_content ( $bcs_bucket, $object, $bits, $opt );
	
	return TRUE;
}

//删除本地文件
function _delete_local_file($file){
	try{
	  //文件不存在
		if(!@file_exists($file))
			return TRUE;
		//删除文件
		if(!@unlink($file))
			return FALSE;
		return TRUE;
	}
	catch(Exception $ex){
		return FALSE;
	}
}

/**
 * 上传所有文件到服务器，没有删除本地文件
 * @param $metadata from function wp_generate_attachment_metadata
 * @return array
 */
function upload_images($metadata)
{	
	//判断是否为图片文件，不是则返回
	if(!defined('BCS_ISIMG'))
		return $metadata;
	//获取上传路径
	$wp_upload_dir = wp_upload_dir();
	$upload_path = get_option('upload_path');
	$bcs_options = get_option('bcs_options', TRUE);
	$bcs_nolocalsaving = (attribute_escape($bcs_options['nolocalsaving'])=='true') ? true : false;
	if($upload_path == '.' )
		$upload_path='/';
	else
		$upload_path = '/' . trim($upload_path,'/').'/';
	
	//上传原始文件
	$object = $upload_path.$metadata['file'];
	$file = $wp_upload_dir['basedir'].'/'.$metadata['file'];
	_file_upload ( $object, $file);
	
	//如果不在本地保存，则删除
	if($bcs_nolocalsaving)
		_delete_local_file($file);

	//上传小尺寸文件
	if (isset($metadata['sizes']) && count($metadata['sizes']) > 0)
	{
		//there may be duplicated filenames,so ....
		foreach ($metadata['sizes'] as $val)
		{
			$object = $upload_path.$wp_upload_dir['subdir'].'/'.$val['file'];
			$file = $wp_upload_dir['path'].'/'.$val['file'];
			$opt =array(
				'headers' => array('Content-Type' => $val['mime-type'])
			);
			_file_upload ( $object, $file, $opt );
			
			/*/如果不在本地保存，则删除*/
			if($bcs_nolocalsaving)
				_delete_local_file($file);

		}
	}
	return $metadata;
}
//生成缩略图后立即上传
add_filter('wp_generate_attachment_metadata', 'upload_images', 999);


/**
 * 上传附件
 * @param $data
 * @return array()
 */
function mv_attachments_to_bcs($data) {
	$type = $data['type'];
	//如果是图片则不必上传
	if( substr_count($type,"image/")>0 ){
		define("BCS_ISIMG",true);
		return $data;
	}
	//获取上传路径
	$wp_upload_dir = wp_upload_dir();
	$upload_path = get_option('upload_path');
	$upload_url_path = get_option('upload_url_path');
	$bcs_options = get_option('bcs_options', TRUE);
	$bcs_nolocalsaving = (attribute_escape($bcs_options['nolocalsaving'])=='true') ? true : false;
	if($upload_path == '.' )
		$upload_path='';
	else
		$upload_path = '/' . trim($upload_path,'/');
	
	//上传原始文件
	$object = $upload_path.$wp_upload_dir['subdir'].'/'.basename($data['file']);
	$file = $data['file'];
	$opt =array(
		'headers' => array('Content-Type' => $type)
	);
	_file_upload ( $object, $file, $opt);
	//_file_upload_by_contents ( "/".basename($data['file']).".txt", $object.'      '.$file, array('headers' => array('Content-Type' => 'text/plain')));//
	
	/*/如果不在本地保存，则删除*/
	if($bcs_nolocalsaving){
		_delete_local_file($file);
	}
	return $data;
}

add_filter('wp_handle_upload', 'mv_attachments_to_bcs');


/**
 * 删除远程服务器上的单个文件
 * @static
 * @param $file
 * @return $file
 */
function delete_remote_file($file)
{	
	require_once('bcs.class.php');
	
	//获取WP配置信息
	$bcs_options = get_option('bcs_options', TRUE);
    $bcs_bucket = attribute_escape($bcs_options['bucket']);
	$bcs_ak = attribute_escape($bcs_options['ak']);
	$bcs_sk = attribute_escape($bcs_options['sk']);

	//获取保存路径
	$upload_path = get_option('upload_path');
	if($upload_path == '.' )
		$upload_path='/';
	else
		$upload_path = '/' . trim($upload_path,'/').'/';
	
	//获取上传路径
	$wp_upload_dir = wp_upload_dir();
	
	$delFile = str_replace($wp_upload_dir['basedir'],'',$file);
	$delFile = str_replace('./','',$delFile);
	$delFile = $upload_path . ltrim( $delFile , '/' );
	
	//实例化存储对象
	if(!is_object($baidu_bcs))
		$baidu_bcs = new BaiduBCS($bcs_ak, $bcs_sk);
	//删除文件
	@$baidu_bcs->delete_object($bcs_bucket,$delFile);
	return $file;
}

//删除远程附件
add_action('wp_delete_file', 'delete_remote_file');

function bcs_plugin_action_links( $links, $file ) {
	if ( $file == plugin_basename( dirname(__FILE__).'/bcs-support.php' ) ) {
		$links[] = '<a href="options-general.php?page=' . BCS_BASEFOLDER . '/bcs-support.php">'.__('Settings').'</a>';
	}

	return $links;
}

add_filter( 'plugin_action_links', 'bcs_plugin_action_links', 10, 2 );

function bcs_add_setting_page() {
    add_options_page('BCS Setting', 'BCS Setting', 8, __FILE__, 'bcs_setting_page');
}

add_action('admin_menu', 'bcs_add_setting_page');

function bcs_setting_page() {

	$options = array();
	if($_POST['bucket']) {
		$options['bucket'] = trim(stripslashes($_POST['bucket']));
	}
	if($_POST['ak']) {
		$options['ak'] = trim(stripslashes($_POST['ak']));
	}
	if($_POST['sk']) {
		$options['sk'] = trim(stripslashes($_POST['sk']));
	}
	if($_POST['nolocalsaving']) {
		$options['nolocalsaving'] = (isset($_POST['nolocalsaving']))?'true':'false';
	}

	//检查AK/SK是否有该Bucket的管理权限
	$flag = 1;
	if($_POST['bucket']&&$_POST['ak']&&$_POST['sk']&&$_POST['addr']){
		require_once('bcs.class.php');
		$flag = 0;
		$baidu_bcs = new BaiduBCS( $options['ak'], $options['sk'] );
		$ret = $baidu_bcs->list_bucket();
		$all_buckets = json_decode($ret->body);
		foreach($all_buckets as $b){
			if($b->bucket_name!=$options['bucket'])
				continue;
			else{
				$flag = 1; break;
			}
		}
	}

	if($options !== array() ){
	
		update_option('bcs_options', $options);
        update_option('upload_path', trim(stripslashes($_POST['upload_path'])) );
		update_option('upload_url_path', trim(stripslashes($_POST['upload_url_path'])) );
?>
<div class="updated"><p><strong>设置已保存！<?php if($flag==0) echo '<span style="color:#F00">注意，您的AK/SK没有管理该Bucket的权限，因此不能正常使用！</span>'; ?></strong></p></div>
<?php
    }

    $bcs_options = get_option('bcs_options', TRUE);
	$upload_path = get_option('upload_path');
	$upload_url_path = get_option('upload_url_path');

    $bcs_bucket = attribute_escape($bcs_options['bucket']);
    $bcs_ak = attribute_escape($bcs_options['ak']);
    $bcs_sk = attribute_escape($bcs_options['sk']);
	
	$bcs_nolocalsaving = attribute_escape($bcs_options['nolocalsaving']);
	($bcs_nolocalsaving == 'true') ? ($bcs_nolocalsaving = true) : ($bcs_nolocalsaving = false);
?>
<div class="wrap" style="margin: 10px;">
    <h2>百度云存储 设置</h2>
    <form name="form1" method="post" action="<?php echo wp_nonce_url('./options-general.php?page=' . BCS_BASEFOLDER . '/bcs-support.php'); ?>">
        <fieldset>
            <legend>Bucket 设置</legend>
            <input type="text" name="bucket" value="<?php echo $bcs_bucket;?>" placeholder="请输入云存储使用的 bucket"/>
            <p>请先访问 <a href="http://developer.baidu.com/bae/bcs/bucket/">百度云存储</a> 创建 bucket 后，填写以上内容。</p>
        </fieldset>
        <fieldset>
            <legend>Access Key / API key</legend>
            <input type="text" name="ak" value="<?php echo $bcs_ak;?>" placeholder=""/>
            <p>访问 <a href="http://developer.baidu.com/bae/ref/key/" target="_blank">BAE 密钥管理页面</a>，获取 AK/SK</p>
        </fieldset>
        <fieldset>
            <legend>Secret Key</legend>
            <input type="text" name="sk" value="<?php echo $bcs_sk;?>" placeholder=""/>
        </fieldset>
        <fieldset>
            <legend>不在本地保留备份：</legend>
            <input type="checkbox" name="nolocalsaving" <?php if($bcs_nolocalsaving) echo 'checked="TRUE"';?> />
        </fieldset>
        <fieldset>
            <legend><br/><br/>---------------WordPress系统配置-----------<br/>默认上传路径：</legend>
            <input type="text" name="upload_path" value="<?php echo $upload_path;?>" placeholder="默认上传路径"/>
            <p>例如：.</p>
        </fieldset>
        <fieldset>
            <legend>文件的完整 URL 地址：</legend>
            <input type="text" name="upload_url_path" value="<?php echo $upload_url_path;?>" placeholder="文件的完整 URL 地址"/>
            <p>例如：http://bucket.bcs.duapp.com</p>
        </fieldset>
        <fieldset class="submit">
            <input type="submit" name="submit" value="更新" />
        </fieldset>
    </form>
</div>
<?php
}
?>