=== 百度云附件 ===
Contributors: 马文建(Wenjian Ma)
Donate link: http://mawenjian.net/976.html
Tags: attachment, baidu, manager, images, thumbnail
Requires at least: 1.5
Tested up to: 3.5.1
Stable tag: 1.1

使用百度云存储BCS作为附件存储空间。
This is a plugin that used Baidu Cloud Storage(BCS) for attachments remote saving.

== Description ==

该插件支持使用百度云存储BCS作为附件存储空间。
This is a plugin that used Baidu Cloud Storage(BCS) for attachments remote saving.

== Installation ==

1. 下载，解压缩并上传到WordPress插件目录
2. 在插件管理后台激活插件
3. 工具 > BCS Support 

1. Download, unzip and upload to your WordPress plugins directory
2. activate the plugin within you WordPress Administration Backend
3. Go to Tools > BCS Support

### Screenshots

![截图](screenshot.jpg "截图")

== Changelog ==

= 1.1 =
* 修复只能上传图片而不能上传其他多媒体文件的BUG；
* 用户更新AK/SK/BUCKET后增加验证功能，避免因为AK/SK/BUCKET填写错误而出现不必要的问题；
* 将“默认上传路径”和“文件的完整 URL 地址”集成到插件管理页面，只需在一个页面即可配置成功；

= 1.0 =
* 实现基本功能