=== WP anti spam dali ===

Contributors: 露兜
Donate link: http://www.ludou.org/wp-anti-spam-dali.html
Tags: spam,filter,chinese,all-in-one
Requires at least: 2.7
Tested up to: 3.1
Stable tag: 1.0

== Description ==

= 功能 =
1. 阻止程序自动发布的垃圾评论
2. 限定评论字数，防止灌水
3. 评论关键字替换，防止被和谐
4. 只允许含有中文的评论，组织英文垃圾评论
5. 防范他人冒充博主发布评论
6. 转义评论中的所有代码，防止恶意代码攻击
7. 过滤评论中的链接，利于SEO

以上功能皆可在后台自助开启和关闭.

== Installation ==

安装只需下载压缩包，解压后，把`wp-anti-spam-dali`文件夹上传到`/wp-content/plugins/`文件夹中，
最后在后台激活即可使用，在后台 - 设置 - 大篱评论过滤，可以设置插件选项。

== Changelog ==

= 1.0 =

* First version