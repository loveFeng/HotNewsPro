<div class="footer_content">
	&#169; <?php print(date(Y)); ?> <?php bloginfo('name'); ?>&nbsp;&nbsp;<?php wp_loginout(); wp_register('  ', ''); ?><br/>
	<p>Design by <a target="_blank" href="http://zmingcx.com">Robin</a>&nbsp;&nbsp;</p>
</div> 
<?php wp_footer(); ?>
</body>
</html>